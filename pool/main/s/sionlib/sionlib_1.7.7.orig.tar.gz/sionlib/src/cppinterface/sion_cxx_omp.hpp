#ifndef SION_CXX_OMP_HPP_
#define SION_CXX_OMP_HPP_

#endif
