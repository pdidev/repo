void ppminit_(int *direction);
void ppminitsmooth_(int *direction);
void ppmwriter_(int *a, int *nx, int *ny, int *minval, int *maxval, char *filename);
