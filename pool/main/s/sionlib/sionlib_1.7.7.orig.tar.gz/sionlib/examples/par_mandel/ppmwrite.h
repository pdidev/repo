int ppminit(int direction);
int ppminitsmooth(int direction);
void ppmwrite(int*  a,
              int   nx,
              int   ny,
              int   minval,
              int   maxval,
              char* filename);
