#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "fti.static" for configuration "Release"
set_property(TARGET fti.static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(fti.static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/usr/lib/x86_64-linux-gnu/fti/openmpi/libfti.a"
  )

list(APPEND _IMPORT_CHECK_TARGETS fti.static )
list(APPEND _IMPORT_CHECK_FILES_FOR_fti.static "/usr/lib/x86_64-linux-gnu/fti/openmpi/libfti.a" )

# Import target "fti.shared" for configuration "Release"
set_property(TARGET fti.shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(fti.shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/usr/lib/x86_64-linux-gnu/fti/openmpi/libfti.so"
  IMPORTED_SONAME_RELEASE "libfti.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS fti.shared )
list(APPEND _IMPORT_CHECK_FILES_FOR_fti.shared "/usr/lib/x86_64-linux-gnu/fti/openmpi/libfti.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
