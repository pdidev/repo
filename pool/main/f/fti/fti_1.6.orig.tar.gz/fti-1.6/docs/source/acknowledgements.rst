.. Fault Tolerance Library documentation acknowledgements file


The scientific/academic work is financed from financial resources for science in the years 2016 - 2018 granted for the realization of the international project co-financed by Polish Ministry of Science and Higher Education.

This work has been supported by EU H2020 ICT project LEGaTO, contract #780681 .
