# FIND_PACKAGE_HANDLE_STANDARD_ARGS(<name> ... )
#
# This function is intended to be used in FindXXX.cmake modules files. It
# handles the REQUIRED, QUIET and version-related arguments to find_package() It
# also sets the <UPPERCASED_NAME>_FOUND variable. The package is considered
# found if all variables <var1>... listed contain valid results, e.g. valid
# filepaths.
#
# There are two modes of this function. The first argument in both modes is the
# name of the Find-module where it is called (in original casing).
#
# The first simple mode looks like this:
# FIND_PACKAGE_HANDLE_STANDARD_ARGS(<name> (DEFAULT_MSG| "Custom failure
# message") <var1>...<varN>) If the variables <var1> to <varN> are all valid,
# then <UPPERCASED_NAME>_FOUND will be set to TRUE. If DEFAULT_MSG is given as
# second argument, then the function will generate itself useful success and
# error messages. You can also supply a custom error message for the failure
# case. This is not recommended.
#
# The second mode is more powerful and also supports version checking:
# FIND_PACKAGE_HANDLE_STANDARD_ARGS(NAME [REQUIRED_VARS <var1>...<varN>]
# [VERSION_VAR   <versionvar>] [HANDLE_COMPONENTS] [CONFIG_MODE] [FAIL_MESSAGE
# "Custom failure message"])
#
# As above, if <var1> through <varN> are all valid, <UPPERCASED_NAME>_FOUND will
# be set to TRUE. After REQUIRED_VARS the variables which are required for this
# package are listed. Following VERSION_VAR the name of the variable can be
# specified which holds the version of the package which has been found. If this
# is done, this version will be checked against the (potentially) specified
# required version used in the find_package() call. The EXACT keyword is also
# handled. The default messages include information about the required version
# and the version which has been actually found, both if the version is ok or
# not. If the package supports components, use the HANDLE_COMPONENTS option to
# enable handling them. In this case, find_package_handle_standard_args() will
# report which components have been found and which are missing, and the
# <NAME>_FOUND variable will be set to FALSE if any of the required components
# (i.e. not the ones listed after OPTIONAL_COMPONENTS) are missing. Use the
# option CONFIG_MODE if your FindXXX.cmake module is a wrapper for a
# find_package(... NO_MODULE) call.  In this case VERSION_VAR will be set to
# <NAME>_VERSION and the macro will automatically check whether the Config
# module was found. Via FAIL_MESSAGE a custom failure message can be specified,
# if this is not used, the default message will be displayed.
#
# Example for mode 1:
#
# FIND_PACKAGE_HANDLE_STANDARD_ARGS(LibXml2  DEFAULT_MSG LIBXML2_LIBRARY
# LIBXML2_INCLUDE_DIR)
#
# LibXml2 is considered to be found, if both LIBXML2_LIBRARY and
# LIBXML2_INCLUDE_DIR are valid. Then also LIBXML2_FOUND is set to TRUE. If it
# is not found and REQUIRED was used, it fails with FATAL_ERROR, independent
# whether QUIET was used or not. If it is found, success will be reported,
# including the content of <var1>. On repeated Cmake runs, the same message
# won't be printed again.
#
# Example for mode 2:
#
# FIND_PACKAGE_HANDLE_STANDARD_ARGS(BISON  REQUIRED_VARS BISON_EXECUTABLE
# VERSION_VAR BISON_VERSION) In this case, BISON is considered to be found if
# the variable(s) listed after REQUIRED_VAR are all valid, i.e. BISON_EXECUTABLE
# in this case. Also the version of BISON will be checked by using the version
# contained in BISON_VERSION. Since no FAIL_MESSAGE is given, the default
# messages will be printed.
#
# Another example for mode 2:
#
# find_package(Automoc4 QUIET NO_MODULE HINTS /opt/automoc4)
# FIND_PACKAGE_HANDLE_STANDARD_ARGS(Automoc4  CONFIG_MODE) In this case,
# FindAutmoc4.cmake wraps a call to find_package(Automoc4 NO_MODULE) and adds an
# additional search directory for automoc4. The following
# FIND_PACKAGE_HANDLE_STANDARD_ARGS() call produces a proper success/error
# message.

# =============================================================================
# Copyright 2007-2009 Kitware, Inc.
#
# Distributed under the OSI-approved BSD License (the "License"); see
# accompanying file Copyright.txt for details.
#
# This software is distributed WITHOUT ANY WARRANTY; without even the implied
# warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# License for more information.
# =============================================================================
# (To distribute this file outside of CMake, substitute the full License text
# for the above reference.)
include(FindPackageMessage)
include(CMakeParseArguments)

# internal helper macro
macro(_FPHSA_FAILURE_MESSAGE _msg)
  if(${_NAME}_FIND_REQUIRED)
    message(FATAL_ERROR "${_msg}")
  else()
    if(NOT ${_NAME}_FIND_QUIETLY)
      message(STATUS "${_msg}")
    endif()
  endif()
endmacro()

# internal helper macro to generate the failure message when used in
# CONFIG_MODE:
macro(_FPHSA_HANDLE_FAILURE_CONFIG_MODE)
  # <name>_CONFIG is set, but FOUND is false, this means that some other of the
  # REQUIRED_VARS was not found:
  if(${_NAME}_CONFIG)
    _fphsa_failure_message("${FPHSA_FAIL_MESSAGE}: missing: ${MISSING_VARS}
     (found ${${_NAME}_CONFIG} ${VERSION_MSG})")
  else()
    # If _CONSIDERED_CONFIGS is set, the config-file has been found, but no
    # suitable version. List them all in the error message:
    if(${_NAME}_CONSIDERED_CONFIGS)
      set(configsText "")
      list(LENGTH ${_NAME}_CONSIDERED_CONFIGS configsCount)
      math(EXPR configsCount "${configsCount} - 1")
      foreach(currentConfigIndex RANGE ${configsCount})
        list(GET ${_NAME}_CONSIDERED_CONFIGS ${currentConfigIndex} filename)
        list(GET ${_NAME}_CONSIDERED_VERSIONS ${currentConfigIndex} version)
        set(configsText "${configsText}    ${filename} (version ${version})\n")
      endforeach()
      if(${_NAME}_NOT_FOUND_MESSAGE)
        set(configsText "${configsText}    Reason given by package:
         ${${_NAME}_NOT_FOUND_MESSAGE}\n")
      endif()
      _fphsa_failure_message("${FPHSA_FAIL_MESSAGE} ${VERSION_MSG},
       checked the following files:\n${configsText}")

    else()
      # Simple case: No Config-file was found at all:
      _fphsa_failure_message("${FPHSA_FAIL_MESSAGE}: found neither
       ${_NAME}Config.cmake nor ${_NAME_LOWER}-config.cmake ${VERSION_MSG}")
    endif()
  endif()
endmacro()
# Function comment
function(FIND_PACKAGE_HANDLE_STANDARD_ARGS _NAME _FIRST_ARG)
  # set up the arguments for CMAKE_PARSE_ARGUMENTS and check whether we are in
  # new extended or in the "old" mode:
  set(options CONFIG_MODE HANDLE_COMPONENTS)
  set(oneValueArgs FAIL_MESSAGE VERSION_VAR)
  set(multiValueArgs REQUIRED_VARS)
  set(_KEYWORDS_FOR_EXTENDED_MODE ${options} ${oneValueArgs} ${multiValueArgs})
  list(FIND _KEYWORDS_FOR_EXTENDED_MODE "${_FIRST_ARG}" INDEX)
  if(${INDEX} EQUAL -1)
    set(FPHSA_FAIL_MESSAGE ${_FIRST_ARG})
    set(FPHSA_REQUIRED_VARS ${ARGN})
    set(FPHSA_VERSION_VAR)
  else()
    cmake_parse_arguments(FPHSA "${options}" "${oneValueArgs}"
                          "${multiValueArgs}" ${_FIRST_ARG} ${ARGN})
    if(FPHSA_UNPARSED_ARGUMENTS)
      message(FATAL_ERROR "Unknown keywords given to
       FIND_PACKAGE_HANDLE_STANDARD_ARGS(): \"${FPHSA_UNPARSED_ARGUMENTS}\"")
    endif()
    if(NOT FPHSA_FAIL_MESSAGE)
      set(FPHSA_FAIL_MESSAGE "DEFAULT_MSG")
    endif()
  endif()

  # now that we collected all arguments, process them
  if("${FPHSA_FAIL_MESSAGE}" STREQUAL "DEFAULT_MSG")
    set(FPHSA_FAIL_MESSAGE "Could NOT find ${_NAME}")
  endif()

  # In config-mode, we rely on the variable <package>_CONFIG, which is set by
  # find_package() when it successfully found the config-file, including version
  # checking:
  if(FPHSA_CONFIG_MODE)
    list(INSERT FPHSA_REQUIRED_VARS 0 ${_NAME}_CONFIG)
    list(REMOVE_DUPLICATES FPHSA_REQUIRED_VARS)
    set(FPHSA_VERSION_VAR ${_NAME}_VERSION)
  endif()
  if(NOT FPHSA_REQUIRED_VARS)
    message(FATAL_ERROR "No REQUIRED_VARS specified for
     FIND_PACKAGE_HANDLE_STANDARD_ARGS()")
  endif()
  list(GET FPHSA_REQUIRED_VARS 0 _FIRST_REQUIRED_VAR)
  string(TOUPPER ${_NAME} _NAME_UPPER)
  string(TOLOWER ${_NAME} _NAME_LOWER)

  # collect all variables which were not found, so they can be printed, so the
  # user knows better what went wrong (#6375)
  set(MISSING_VARS "")
  set(DETAILS "")
  set(${_NAME_UPPER}_FOUND TRUE)
  # check if all passed variables are valid
  foreach(_CURRENT_VAR ${FPHSA_REQUIRED_VARS})
    if(NOT ${_CURRENT_VAR})
      set(${_NAME_UPPER}_FOUND FALSE)
      set(MISSING_VARS "${MISSING_VARS} ${_CURRENT_VAR}")
    else()
      set(DETAILS "${DETAILS}[${${_CURRENT_VAR}}]")
    endif()
  endforeach()

  # component handling
  unset(FOUND_COMPONENTS_MSG)
  unset(MISSING_COMPONENTS_MSG)
  if(FPHSA_HANDLE_COMPONENTS)
    foreach(comp ${${_NAME}_FIND_COMPONENTS})
      if(${_NAME}_${comp}_FOUND)
        if(NOT DEFINED FOUND_COMPONENTS_MSG)
          set(FOUND_COMPONENTS_MSG "found components: ")
        endif()
        set(FOUND_COMPONENTS_MSG "${FOUND_COMPONENTS_MSG} ${comp}")
      else()
        if(NOT DEFINED MISSING_COMPONENTS_MSG)
          set(MISSING_COMPONENTS_MSG "missing components: ")
        endif()
        set(MISSING_COMPONENTS_MSG "${MISSING_COMPONENTS_MSG} ${comp}")
        if(${_NAME}_FIND_REQUIRED_${comp})
          set(${_NAME_UPPER}_FOUND FALSE)
          set(MISSING_VARS "${MISSING_VARS} ${comp}")
        endif()

      endif()
    endforeach()
    set(COMPONENT_MSG "${FOUND_COMPONENTS_MSG} ${MISSING_COMPONENTS_MSG}")
    set(DETAILS "${DETAILS}[c${COMPONENT_MSG}]")
  endif()

  # version handling:
  set(VERSION_MSG "")
  set(VERSION_OK TRUE)
  set(VERSION ${${FPHSA_VERSION_VAR}})
  if(${_NAME}_FIND_VERSION)
    if(VERSION)
      if(${_NAME}_FIND_VERSION_EXACT) # exact version required
        if(NOT "${${_NAME}_FIND_VERSION}" VERSION_EQUAL "${VERSION}")
          set(VERSION_MSG "Found unsuitable version \"${VERSION}\",
           but required is exact version \"${${_NAME}_FIND_VERSION}\"")
          set(VERSION_OK FALSE)
        else()
          set(VERSION_MSG "(found suitable exact version \"${VERSION}\")")
        endif()

      else() # minimum version specified:
        if("${${_NAME}_FIND_VERSION}" VERSION_GREATER "${VERSION}")
          set(VERSION_MSG "Found unsuitable version \"${VERSION}\",
           but required is at least \"${${_NAME}_FIND_VERSION}\"")
          set(VERSION_OK FALSE)
        else()
          set(VERSION_MSG "(found suitable version \"${VERSION}\",
           minimum required is \"${${_NAME}_FIND_VERSION}\")")
        endif()
      endif()

    else()
      # if the package was not found, but a version was given, add that to the
      # output:
      if(${_NAME}_FIND_VERSION_EXACT)
        set(VERSION_MSG "(Required is exact version
          \"${${_NAME}_FIND_VERSION}\")")
      else()
        set(VERSION_MSG "(Required is at least version
          \"${${_NAME}_FIND_VERSION}\")")
      endif()

    endif()
  else()
    if(VERSION)
      set(VERSION_MSG "(found version \"${VERSION}\")")
    endif()
  endif()
  if(VERSION_OK)
    set(DETAILS "${DETAILS}[v${VERSION}(${${_NAME}_FIND_VERSION})]")
  else()
    set(${_NAME_UPPER}_FOUND FALSE)
  endif()

  # print the result:
  if(${_NAME_UPPER}_FOUND)
    find_package_message(${_NAME} "Found ${_NAME}: ${${_FIRST_REQUIRED_VAR}}
     ${VERSION_MSG} ${COMPONENT_MSG}" "${DETAILS}")
  else()
    if(FPHSA_CONFIG_MODE)
      _fphsa_handle_failure_config_mode()
    else()
      if(NOT VERSION_OK)
        _fphsa_failure_message("${FPHSA_FAIL_MESSAGE}: ${VERSION_MSG}
         (found ${${_FIRST_REQUIRED_VAR}})")
      else()
        _fphsa_failure_message("${FPHSA_FAIL_MESSAGE} (missing: ${MISSING_VARS})
         ${VERSION_MSG}")
      endif()
    endif()

  endif()
  set(${_NAME_UPPER}_FOUND
      ${${_NAME_UPPER}_FOUND}
      PARENT_SCOPE)

endfunction()
