#ifndef __FTI_DEFS__
#define __FTI_DEFS__
#endif // __FTI_DEFS__
