
#ifndef PARACONF_EXPORT_H
#define PARACONF_EXPORT_H

#ifdef PARACONF_STATIC_DEFINE
#  define PARACONF_EXPORT
#  define PARACONF_NO_EXPORT
#else
#  ifndef PARACONF_EXPORT
#    ifdef paraconf_EXPORTS
        /* We are building this library */
#      define PARACONF_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define PARACONF_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef PARACONF_NO_EXPORT
#    define PARACONF_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef PARACONF_DEPRECATED
#  define PARACONF_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef PARACONF_DEPRECATED_EXPORT
#  define PARACONF_DEPRECATED_EXPORT PARACONF_EXPORT PARACONF_DEPRECATED
#endif

#ifndef PARACONF_DEPRECATED_NO_EXPORT
#  define PARACONF_DEPRECATED_NO_EXPORT PARACONF_NO_EXPORT PARACONF_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef PARACONF_NO_DEPRECATED
#    define PARACONF_NO_DEPRECATED
#  endif
#endif

#endif /* PARACONF_EXPORT_H */
