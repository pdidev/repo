#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "paraconf::paraconf" for configuration "Release"
set_property(TARGET paraconf::paraconf APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(paraconf::paraconf PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libparaconf.so.0.4.8"
  IMPORTED_SONAME_RELEASE "libparaconf.so.0"
  )

list(APPEND _IMPORT_CHECK_TARGETS paraconf::paraconf )
list(APPEND _IMPORT_CHECK_FILES_FOR_paraconf::paraconf "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libparaconf.so.0.4.8" )

# Import target "paraconf::paraconf_f90" for configuration "Release"
set_property(TARGET paraconf::paraconf_f90 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(paraconf::paraconf_f90 PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libparaconf_f90.so.0.4.8"
  IMPORTED_SONAME_RELEASE "libparaconf_f90.so.0"
  )

list(APPEND _IMPORT_CHECK_TARGETS paraconf::paraconf_f90 )
list(APPEND _IMPORT_CHECK_FILES_FOR_paraconf::paraconf_f90 "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libparaconf_f90.so.0.4.8" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
