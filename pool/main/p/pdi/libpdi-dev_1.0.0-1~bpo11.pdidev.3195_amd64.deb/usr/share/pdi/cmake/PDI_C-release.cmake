#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "PDI::PDI_C" for configuration "Release"
set_property(TARGET PDI::PDI_C APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(PDI::PDI_C PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "spdlog::spdlog"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libpdi.so.1.0.0"
  IMPORTED_SONAME_RELEASE "libpdi.so.1"
  )

list(APPEND _IMPORT_CHECK_TARGETS PDI::PDI_C )
list(APPEND _IMPORT_CHECK_FILES_FOR_PDI::PDI_C "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libpdi.so.1.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
