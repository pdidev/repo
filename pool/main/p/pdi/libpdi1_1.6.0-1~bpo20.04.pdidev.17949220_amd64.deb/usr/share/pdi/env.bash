#!/bin/echo 'please source this file, do not run it'

if [ -z "$PDI_DIR" ]; then

# this file in in INSTALL_PDIDATADIR, go up as many directories as it contains
PDI_DATADIR="share/pdi"
PDI_DIR="$(readlink -f "$(dirname "${BASH_SOURCE[0]}")")"
while [ "$(readlink -f "/${PDI_DATADIR}")" != "/" ]
do
	PDI_DATADIR="$(dirname "${PDI_DATADIR}")"
	PDI_DIR="$(dirname "${PDI_DIR}")"
done
export PDI_DIR

if [ -n "$PATH" ]; then
	export PATH="${PDI_DIR}/bin/:$PATH"
else
	export PATH="${PDI_DIR}/bin/"
fi

if [ -n "$LD_LIBRARY_PATH" ]; then
	export LD_LIBRARY_PATH="${PDI_DIR}/lib/x86_64-linux-gnu/:$LD_LIBRARY_PATH"
else
	export LD_LIBRARY_PATH="${PDI_DIR}/lib/x86_64-linux-gnu/"
fi

if [ -n "$PYTHONPATH" ]; then
	export PYTHONPATH="${PDI_DIR}/lib/python3/dist-packages/:$PYTHONPATH"
else
	export PYTHONPATH="${PDI_DIR}/lib/python3/dist-packages/"
fi

if [ -n "$LIBRARY_PATH" ]; then
	export LIBRARY_PATH="${PDI_DIR}/lib/x86_64-linux-gnu/:$LIBRARY_PATH"
else
	export LIBRARY_PATH="${PDI_DIR}/lib/x86_64-linux-gnu/"
fi

if [ -n "$CPATH" ]; then
	export CPATH="${PDI_DIR}/include/:${PDI_DIR}//usr/lib/x86_64-linux-gnu/fortran/x86_64-linux-gnu-gfortran-9:$CPATH"
else
	export CPATH="${PDI_DIR}/include/:${PDI_DIR}//usr/lib/x86_64-linux-gnu/fortran/x86_64-linux-gnu-gfortran-9"
fi

echo "Environment loaded for PDI version 1.6.0"

fi # [ -z "$PDI_DIR" ]
