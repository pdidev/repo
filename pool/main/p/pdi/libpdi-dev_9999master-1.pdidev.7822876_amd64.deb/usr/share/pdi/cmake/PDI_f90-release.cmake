#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "PDI::PDI_f90" for configuration "Release"
set_property(TARGET PDI::PDI_f90 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(PDI::PDI_f90 PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libpdi_f90.so.1.0.0-alpha.2021-01-24"
  IMPORTED_SONAME_RELEASE "libpdi_f90.so.1"
  )

list(APPEND _IMPORT_CHECK_TARGETS PDI::PDI_f90 )
list(APPEND _IMPORT_CHECK_FILES_FOR_PDI::PDI_f90 "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libpdi_f90.so.1.0.0-alpha.2021-01-24" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
