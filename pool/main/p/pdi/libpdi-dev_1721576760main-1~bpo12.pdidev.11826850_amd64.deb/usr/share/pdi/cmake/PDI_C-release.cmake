#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "PDI::PDI_C" for configuration "Release"
set_property(TARGET PDI::PDI_C APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(PDI::PDI_C PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "spdlog::spdlog"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libpdi.so.1.9.0-alpha.2024-12-05"
  IMPORTED_SONAME_RELEASE "libpdi.so.1"
  )

list(APPEND _cmake_import_check_targets PDI::PDI_C )
list(APPEND _cmake_import_check_files_for_PDI::PDI_C "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libpdi.so.1.9.0-alpha.2024-12-05" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
